#!/usr/bin/env python3
"""
plot_boxplot_all.py – Lager boksplott av feil fra alle Alpha5-loggfiler i en mappe.

Bruk:
  python3 plot_boxplot_all.py [mappe_med_csv]
  Standard er nåværende katalog (der du står i terminalen).
"""

import sys
import os
import glob
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def main():
    # Mappe: enten fra kommandolinje eller '.'
    if len(sys.argv) > 1:
        folder = sys.argv[1]
    else:
        folder = "."

    # Finn alle CSV-filer (Windows-håndtering via os.path.join)
    csv_files = sorted(glob.glob(os.path.join(folder, "*.csv")))
    if not csv_files:
        print(f"Ingen CSV-filer funnet i '{folder}'.")
        sys.exit(1)

    print(f"Leser {len(csv_files)} filer: {', '.join(os.path.basename(f) for f in csv_files)}")

    # Les alle filer og legg til 'point' kolonne fra filnavnet (uten .csv)
    df_list = []
    for f in csv_files:
        point = os.path.splitext(os.path.basename(f))[0]   # f.eks. "P1"
        try:
            df = pd.read_csv(f)
            df['point'] = point
            df_list.append(df)
        except Exception as e:
            print(f"Advarsel: Kunne ikke lese {f}: {e}")

    if not df_list:
        print("Ingen gyldige CSV-data funnet.")
        sys.exit(1)

    df = pd.concat(df_list, ignore_index=True)

    # Sjekk nødvendige kolonner
    required_cols = ["method", "err_x_fwd", "err_y_left", "err_z_down", "err_norm"]
    for col in required_cols:
        if col not in df.columns:
            print(f"Mangler kolonne '{col}' i en av CSV-filene.")
            sys.exit(1)

    # Skriv ut oppsummering
    methods = df["method"].unique()
    points = df["point"].unique()
    print(f"Metoder: {', '.join(methods)}")
    print(f"Punkter: {', '.join(points)}")
    print(f"Totalt antall rader: {len(df)}")

    sns.set_style("whitegrid")

    # ---- Plott 1: Feilnorm per metode (alle punkter samlet) ----
    plt.figure(figsize=(10, 6))
    sns.boxplot(data=df, x="method", y="err_norm")
    plt.title("Feilnorm per metode (alle punkter samlet)")
    plt.xlabel("Metode")
    plt.ylabel("Feil [m]")
    plt.tight_layout()
    plt.savefig("boxplot_err_norm_all_points.png")
    plt.show()

    # ---- Plott 2: Feilnorm per punkt og metode ----
    plt.figure(figsize=(12, 6))
    sns.boxplot(data=df, x="point", y="err_norm", hue="method")
    plt.title("Feilnorm per punkt og metode")
    plt.xlabel("Punkt")
    plt.ylabel("Feil [m]")
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.tight_layout()
    plt.savefig("boxplot_err_norm_by_point.png")
    plt.show()

    # ---- Plott 3: Komponentvise feil per metode ----
    comps = ["err_x_fwd", "err_y_left", "err_z_down"]
    titles = ["Feil X (fremover)", "Feil Y (venstre)", "Feil Z (nedover)"]
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    for ax, comp, title in zip(axes, comps, titles):
        sns.boxplot(data=df, x="method", y=comp, ax=ax)
        ax.set_title(title)
        ax.set_xlabel("Metode")
        ax.set_ylabel("Feil [m]")
    plt.tight_layout()
    plt.savefig("boxplot_components_per_method.png")
    plt.show()

    # ---- Plott 4: Komponentfeil per punkt og metode ----
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    for ax, comp, title in zip(axes, comps, titles):
        sns.boxplot(data=df, x="point", y=comp, hue="method", ax=ax)
        ax.set_title(title)
        ax.set_xlabel("Punkt")
        ax.set_ylabel("Feil [m]")
    plt.tight_layout()
    plt.savefig("boxplot_components_by_point.png")
    plt.show()

if __name__ == "__main__":
    main()