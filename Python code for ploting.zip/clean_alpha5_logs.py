#!/usr/bin/env python3
"""
clean_alpha5_logs.py – Fjerner hastighets‑spiker fra Alpha5 loggfiler.

Spikene kommer av at gripperleddet (joint_b) "wrappes" fra 2π til 0,
noe som gir enorme falske hastigheter i kolonnene vel_e … vel_b.
Skriptet lager en ny utgave av hver fil (suffix _clean.csv) der:

- joint_b og alle hastigheter rekonstrueres fra en kontinuerlig
  (unwrapped) vinkel.
- Alle andre kolonner (tid, method, point_id, feil osv.) beholdes
  uendret, fordi feilberegningene er basert på FK med den wrappede
  vinkelen – de er allerede korrekte.

Bruk:
  python3 clean_alpha5_logs.py [mappe]
  Standard er nåværende katalog.

Avhengigheter: pandas, numpy
"""

import sys
import os
import glob
import numpy as np
import pandas as pd

def unwrap_joint_b(df: pd.DataFrame) -> pd.Series:
    """Bygg en kontinuerlig (unwrapped) joint_b.
    Anta at kolonnene 'joint_b' og 'time' finnes.
    """
    b_raw = df['joint_b'].values
    time = df['time'].values
    unwrapped = np.zeros_like(b_raw)
    unwrapped[0] = b_raw[0]
    offset = 0.0
    for i in range(1, len(b_raw)):
        diff = b_raw[i] - b_raw[i-1]
        if diff > np.pi:
            offset -= 2.0 * np.pi
        elif diff < -np.pi:
            offset += 2.0 * np.pi
        unwrapped[i] = b_raw[i] + offset
    return pd.Series(unwrapped, index=df.index)

def recompute_velocities(df: pd.DataFrame) -> pd.DataFrame:
    """Beregn hastigheter på nytt fra de opprinnelige leddvinklene,
    men med unwrapped joint_b for å unngå spiker.
    Returner en kopi av df med oppdaterte vel_kolonner.
    """
    df = df.copy()
    # Unwrap joint_b
    if 'joint_b' in df.columns:
        joint_b_unwrapped = unwrap_joint_b(df)
    else:
        joint_b_unwrapped = df['joint_b']  # fallback

    # Tidsdifferanser for hvert steg
    t = df['time'].values
    dt = np.diff(t)
    # For å ha samme lengde som posisjonene: legg til NaN for første rad
    dt_full = np.concatenate([np.array([np.nan]), dt])

    joints = ['joint_e', 'joint_d', 'joint_c']
    # For joint_b bruk unwrapped
    pos = {'joint_e': df['joint_e'].values,
           'joint_d': df['joint_d'].values,
           'joint_c': df['joint_c'].values,
           'joint_b': joint_b_unwrapped.values}

    # Beregn hastigheter som fremoverdifferanser
    for j in joints + ['joint_b']:
        col = j.replace('joint_', 'vel_')
        q = pos[j]
        # Fremoverdifferanse: dq/dt
        dq = np.full_like(q, np.nan)
        dq[1:] = (q[1:] - q[:-1]) / dt
        df[col] = dq

    return df

def clean_file(filepath: str) -> None:
    """Les, rens og skriv ut en _clean.csv ved siden av originalen."""
    print(f"Behandler {os.path.basename(filepath)} …", end=" ")
    try:
        df = pd.read_csv(filepath)
    except Exception as e:
        print(f"FEIL: {e}")
        return

    # Sjekk at nødvendige kolonner finnes
    required = ['time', 'joint_e', 'joint_d', 'joint_c', 'joint_b',
                'vel_e', 'vel_d', 'vel_c', 'vel_b']
    missing = [c for c in required if c not in df.columns]
    if missing:
        print(f"Mangler kolonner: {missing} – hopper over.")
        return

    # Sorter etter tid (sikkerhet)
    df = df.sort_values('time').reset_index(drop=True)

    # Rens hastighetene
    df_clean = recompute_velocities(df)

    # Lagre
    outpath = filepath.replace('.csv', '_clean.csv')
    df_clean.to_csv(outpath, index=False)
    print(f"OK → {os.path.basename(outpath)}")

def main():
    folder = sys.argv[1] if len(sys.argv) > 1 else "."
    csv_files = sorted(glob.glob(os.path.join(folder, "*.csv")))
    if not csv_files:
        print("Ingen CSV-filer funnet.")
        return

    for f in csv_files:
        # Hopp over filer som allerede er rensede (for å unngå dobbel rensing)
        if f.endswith('_clean.csv'):
            continue
        clean_file(f)

    print("\nAlle filer ferdig behandlet.")
    print("Du kan nå bruke plot_boxplot_all.py eller plot_mean_error.py")
    print("på de nye *_clean.csv-filene for en mer korrekt analyse.")

if __name__ == "__main__":
    main()