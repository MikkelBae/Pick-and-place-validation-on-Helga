#!/usr/bin/env python3
"""
plot_mean_error.py – Beregner gjennomsnittlig feil per metode over alle punkter.

Leser alle CSV-filer i mappen (P1.csv, P2.csv, ...), grupperer dataene på
(point, method), og beregner gjennomsnittlig feilnorm (err_norm) for hvert
punkt og metode. Deretter midles disse verdiene over punktene, og presenteres
som en tabell og et stolpediagram med standardavvik.

Bruk:  python3 plot_mean_error.py [mappe]
Hvis mappe ikke oppgis, brukes nåværende katalog.
"""

import sys
import os
import glob
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

def main():
    # Mappe for CSV-filer
    folder = sys.argv[1] if len(sys.argv) > 1 else "."

    # Finn alle CSV-filer
    csv_files = sorted(glob.glob(os.path.join(folder, "*.csv")))
    if not csv_files:
        print(f"Ingen CSV-filer funnet i '{folder}'.")
        sys.exit(1)

    print(f"Leser {len(csv_files)} filer: {', '.join(os.path.basename(f) for f in csv_files)}")

    # Les inn og sett punktnavn fra filnavn (uten .csv)
    df_list = []
    for f in csv_files:
        point = os.path.splitext(os.path.basename(f))[0]   # f.eks. "P1"
        try:
            df = pd.read_csv(f)
            df['point'] = point
            df_list.append(df)
        except Exception as e:
            print(f"Advarsel: Kunne ikke lese {f}: {e}")

    if not df_list:
        print("Ingen gyldige data.")
        sys.exit(1)

    df_all = pd.concat(df_list, ignore_index=True)

    # Sjekk nødvendige kolonner
    required = ["method", "point", "err_norm"]
    if any(c not in df_all.columns for c in required):
        print("Mangler kolonner i CSV-filene. Trenger: method, err_norm, og point (fra filnavn).")
        sys.exit(1)

    # Steg 1: Gjennomsnittlig err_norm for hvert punkt og metode
    per_point_mean = df_all.groupby(["point", "method"])["err_norm"].mean().reset_index()
    # Steg 2: Gjennomsnitt over punktene for hver metode
    summary = per_point_mean.groupby("method")["err_norm"].agg(["mean", "std", "count"]).reset_index()
    summary.columns = ["method", "mean_error", "std_error", "num_points"]

    # Skriv ut tabell
    print("\n=== Gjennomsnittlig feilnorm per metode (midlet over alle punkter) ===")
    print(f"{'Metode':<15} {'Middel [m]':<12} {'Std [m]':<12} {'Antall punkt':<14}")
    print("-" * 53)
    for _, row in summary.iterrows():
        print(f"{row['method']:<15} {row['mean_error']:<12.6f} {row['std_error']:<12.6f} {row['num_points']:<14}")
    print("-" * 53)

    # Stolpediagram med feilfelt (standardavvik)
    plt.figure(figsize=(10, 6))
    sns.set_style("whitegrid")
    methods = summary["method"].tolist()
    means = summary["mean_error"].values
    stds = summary["std_error"].values
    x = np.arange(len(methods))

    bars = plt.bar(x, means, yerr=stds, capsize=8, color=sns.color_palette("Set2", len(methods)))
    plt.xticks(x, methods)
    plt.ylabel("Gjennomsnittlig feilnorm [m]")
    plt.title("Gjennomsnittlig feilnorm per metode (over alle punkter)")
    plt.tight_layout()
    plt.savefig("mean_error_per_method.png")
    plt.show()

    # Som en bonus: Boksplott av all data (valgfritt)
    plt.figure(figsize=(10, 6))
    sns.boxplot(data=df_all, x="method", y="err_norm")
    plt.title("Feilnorm per metode – alle målinger, alle punkter samlet")
    plt.xlabel("Metode")
    plt.ylabel("Feilnorm [m]")
    plt.tight_layout()
    plt.savefig("boxplot_all_data.png")
    plt.show()

if __name__ == "__main__":
    main()