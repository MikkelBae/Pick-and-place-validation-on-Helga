#!/usr/bin/env python3
"""
plot_joints_3x2_ma.py – Plot positions and velocities for joints e, d, c (3×2)
using a moving average smoother for the velocities.

Usage:  python3 plot_joints_3x2_ma.py <logfile.csv> [window_size]
        window_size (integer, default=1) = number of samples in the
        moving average window. 1 = no smoothing.
"""

import sys
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

def moving_average(data: np.ndarray, window: int) -> np.ndarray:
    """
    Apply a simple moving average (boxcar) smoother.
    The output array has the same length as the input.
    """
    if window <= 1:
        return data
    # Use pandas rolling mean for simplicity
    s = pd.Series(data)
    smoothed = s.rolling(window=window, center=True, min_periods=1).mean()
    return smoothed.values

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 plot_joints_3x2_ma.py <logfile.csv> [window_size]")
        sys.exit(1)

    csv_file = sys.argv[1]
    window = int(sys.argv[2]) if len(sys.argv) > 2 else 1

    try:
        df = pd.read_csv(csv_file)
    except FileNotFoundError:
        print(f"File not found: '{csv_file}'.")
        sys.exit(1)

    # Only use joints e, d, c – joint b is excluded
    joints = ['joint_e', 'joint_d', 'joint_c']
    vels   = ['vel_e', 'vel_d', 'vel_c']
    titles = ['Joint e', 'Joint d', 'Joint c']

    # Check required columns
    required = ['time'] + joints + vels
    missing = [c for c in required if c not in df.columns]
    if missing:
        print(f"Missing columns: {missing}")
        sys.exit(1)

    # Relative time from first sample
    t = df['time'].values
    t_rel = t - t[0]

    fig, axes = plt.subplots(len(joints), 2, figsize=(12, 8), sharex='col')

    for i, (jcol, vcol, title) in enumerate(zip(joints, vels, titles)):
        # --- Position (left column) ---
        ax_pos = axes[i, 0]
        ax_pos.plot(t_rel, df[jcol], linewidth=1.0, color='tab:blue')
        ax_pos.set_ylabel(f'{title}\nPosition [rad]')
        ax_pos.grid(True, alpha=0.3)
        if i == 0:
            ax_pos.set_title('Position')

        # --- Velocity (right column) with moving average smoothing ---
        ax_vel = axes[i, 1]
        vel_raw = df[vcol].values
        vel_smooth = moving_average(vel_raw, window)

        label = f'MA smoothed (w={window})' if window > 1 else 'Raw'
        ax_vel.plot(t_rel, vel_smooth, linewidth=1.0, color='tab:red', label=label)
        ax_vel.set_ylabel('Velocity [rad/s]')
        ax_vel.grid(True, alpha=0.3)
        if window > 1:
            ax_vel.legend(fontsize=7)
        if i == 0:
            ax_vel.set_title('Velocity')

    axes[-1, 0].set_xlabel('Relative time [s]')
    axes[-1, 1].set_xlabel('Relative time [s]')

    plt.tight_layout()
    out_png = csv_file.rsplit('.', 1)[0] + '_joints_3x2_ma.png'
    plt.savefig(out_png, dpi=150)
    print(f"Plot saved as {out_png}")
    plt.show()

if __name__ == '__main__':
    main()