#!/usr/bin/env python3
"""
plot_phase_portrait.py – Faseplott (posisjon vs. hastighet) for hvert ledd.

Bruk:
  python plot_phase_portrait.py <loggfil.csv>

Eksempel:
  python plot_phase_portrait.py slow_planning_log_clean.csv

Krever: pandas, matplotlib
"""

import sys
import pandas as pd
import matplotlib.pyplot as plt

def main():
    if len(sys.argv) < 2:
        print("Bruk: python plot_phase_portrait.py <loggfil.csv>")
        sys.exit(1)

    csv_file = sys.argv[1]

    try:
        df = pd.read_csv(csv_file)
    except FileNotFoundError:
        print(f"Fant ikke filen '{csv_file}'.")
        sys.exit(1)

    # Sjekk at alle nødvendige kolonner finnes
    joints = ['joint_e', 'joint_d', 'joint_c', 'joint_b']
    vels   = ['vel_e', 'vel_d', 'vel_c', 'vel_b']
    needed = joints + vels
    missing = [c for c in needed if c not in df.columns]
    if missing:
        print(f"Mangler kolonner i filen: {missing}")
        sys.exit(1)

    # Fjern rader med NaN i hastigheter (første rad)
    df_clean = df.dropna(subset=vels).copy()

    # Opprett 2x2 paneler
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    axes = axes.flatten()

    for i, (ax, j_col, v_col) in enumerate(zip(axes, joints, vels)):
        ax.plot(df_clean[j_col], df_clean[v_col], linewidth=0.6, alpha=0.8)
        ax.set_xlabel(f'{j_col} [rad]')
        ax.set_ylabel(f'{v_col} [rad/s]')
        ax.set_title(f'Faseportrett: {j_col} mot {v_col}')
        ax.grid(True, alpha=0.3)

    plt.suptitle(f'Faseplott for alle ledd – {csv_file}', fontsize=14)
    plt.tight_layout()

    out_png = csv_file.replace('.csv', '_phase.png')
    plt.savefig(out_png, dpi=150)
    print(f"Plott lagret som {out_png}")
    plt.show()

if __name__ == '__main__':
    main()