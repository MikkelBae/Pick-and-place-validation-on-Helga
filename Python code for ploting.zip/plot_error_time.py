#!/usr/bin/env python3
"""
plot_error_time.py – Tidsplott av feilnorm (err_norm) fra én loggfil.

Bruk:  python plot_error_time.py <loggfil.csv> [--components]

Hvis --components er med, vises også de tre aksene i separate subplots.
"""

import sys
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

def main():
    if len(sys.argv) < 2:
        print("Bruk: python plot_error_time.py <loggfil.csv> [--components]")
        sys.exit(1)

    csv_file = sys.argv[1]
    show_components = "--components" in sys.argv

    try:
        df = pd.read_csv(csv_file)
    except FileNotFoundError:
        print(f"Fant ikke filen '{csv_file}'.")
        sys.exit(1)

    # Sjekk nødvendige kolonner
    required = ["time", "method", "err_norm"]
    if show_components:
        required += ["err_x_fwd", "err_y_left", "err_z_down"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        print(f"Mangler kolonner: {missing}")
        sys.exit(1)

    # Lag relativ tid – starter på 0 for første måling
    df = df.copy()
    df["t_rel"] = df["time"] - df["time"].min()

    # Hent unike metoder
    methods = df["method"].unique()
    print(f"Metoder: {', '.join(methods)}")

    # Farger for hver metode
    colors = plt.cm.tab10(np.linspace(0, 1, len(methods)))

    if show_components:
        # Lag et panel med 4 subplots (err_norm + tre komponenter)
        fig, axes = plt.subplots(4, 1, figsize=(12, 12), sharex=True)
        comps = ["err_norm", "err_x_fwd", "err_y_left", "err_z_down"]
        titles = ["Feilnorm", "Feil X (fremover)", "Feil Y (venstre)", "Feil Z (nedover)"]
        ylabels = ["Feil [m]", "Feil [m]", "Feil [m]", "Feil [m]"]

        for ax, comp, title, ylab in zip(axes, comps, titles, ylabels):
            for i, method in enumerate(methods):
                mask = df["method"] == method
                ax.plot(df.loc[mask, "t_rel"], df.loc[mask, comp],
                        color=colors[i], label=method, linewidth=1.0, alpha=0.9)
            ax.set_title(title)
            ax.set_ylabel(ylab)
            ax.legend(loc="upper right", fontsize=8)
            ax.grid(True, alpha=0.3)
        axes[-1].set_xlabel("Relativ tid [s]")
        plt.tight_layout()
        outname = csv_file.replace(".csv", "_error_time_components.png")
    else:
        # Kun err_norm
        plt.figure(figsize=(12, 5))
        for i, method in enumerate(methods):
            mask = df["method"] == method
            plt.plot(df.loc[mask, "t_rel"], df.loc[mask, "err_norm"],
                     color=colors[i], label=method, linewidth=1.2, alpha=0.9)
        plt.title("Feilnorm over tid")
        plt.xlabel("Relativ tid [s]")
        plt.ylabel("Feil [m]")
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        outname = csv_file.replace(".csv", "_error_time.png")

    plt.savefig(outname, dpi=150)
    print(f"Plott lagret som: {outname}")
    plt.show()

if __name__ == "__main__":
    main()