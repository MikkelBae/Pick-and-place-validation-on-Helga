#!/usr/bin/env python3
"""
plot_single_csv.py – Plott feil fra én Alpha5-loggfil.

Bruk:
  python plot_single_csv.py <loggfil.csv>

Eksempel:
  python plot_single_csv.py P1_dwell.csv

Krever: pandas, matplotlib, seaborn
"""

import sys
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def main():
    # Må ha et filnavn som argument
    if len(sys.argv) < 2:
        print("Bruk: python plot_single_csv.py <loggfil.csv>")
        sys.exit(1)

    csv_file = sys.argv[1]

    # Les filen
    try:
        df = pd.read_csv(csv_file)
    except FileNotFoundError:
        print(f"Fant ikke filen '{csv_file}'.")
        sys.exit(1)

    # Sjekk at nødvendige kolonner finnes
    required = ["method", "err_x_fwd", "err_y_left", "err_z_down", "err_norm"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        print(f"Mangler nødvendige kolonner: {missing}")
        sys.exit(1)

    # Grunnleggende info
    methods = df["method"].unique()
    print(f"Leser '{csv_file}' – {len(df)} rader, metoder: {', '.join(methods)}")
    if "point_id" in df.columns:
        points = df["point_id"].unique()
        print(f"Punkt-ID-er i fila: {points}")

    sns.set_style("whitegrid")

    # ------------------------------------------------------------
    # 1. Boksplott av feilnorm per metode
    # ------------------------------------------------------------
    plt.figure(figsize=(10, 6))
    sns.boxplot(data=df, x="method", y="err_norm")
    plt.title(f"Feilnorm per metode ({csv_file})")
    plt.xlabel("Metode")
    plt.ylabel("Feil [m]")
    plt.tight_layout()
    plt.savefig("boxplot_err_norm_single.png")
    plt.show()

    # ------------------------------------------------------------
    # 2. Komponentfeil per metode (ett panel per komponent)
    # ------------------------------------------------------------
    comps = ["err_x_fwd", "err_y_left", "err_z_down"]
    titles = ["Feil X (fremover)", "Feil Y (venstre)", "Feil Z (nedover)"]
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    for ax, comp, title in zip(axes, comps, titles):
        sns.boxplot(data=df, x="method", y=comp, ax=ax)
        ax.set_title(title)
        ax.set_xlabel("Metode")
        ax.set_ylabel("Feil [m]")
    plt.tight_layout()
    plt.savefig("boxplot_components_single.png")
    plt.show()

    # ------------------------------------------------------------
    # 3. (Valgfritt) Hvis point_id finnes, vis per punkt og metode
    # ------------------------------------------------------------
    if "point_id" in df.columns:
        # Panel med feilnorm + de tre komponentene
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        axes = axes.flatten()
        for ax, var, title in zip(axes, [*comps, "err_norm"],
                                  [*titles, "Feilnorm"]):
            sns.boxplot(data=df, x="point_id", y=var, hue="method", ax=ax)
            ax.set_title(title)
            ax.set_xlabel("Punkt-ID")
            ax.set_ylabel("Feil [m]")
            ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
        plt.tight_layout()
        plt.savefig("boxplot_by_point_single.png")
        plt.show()

    print("Ferdig. Plott lagret som PNG-filer i arbeidsmappa.")

if __name__ == "__main__":
    main()