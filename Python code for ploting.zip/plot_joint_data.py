#!/usr/bin/env python3
"""
plot_joint_data.py – Plott leddposisjoner, hastigheter og feil fra Alpha5-logg.

Bruk:
  python3 plot_joint_data.py <loggfil.csv>

Lager tre paneler:
  1) Leddvinkler (joint_e … joint_b) mot relativ tid.
  2) Leddhastigheter (vel_e … vel_b) mot relativ tid.
  3) Feilkomponenter (err_x_fwd, err_y_left, err_z_down) og feilnorm.

Avhengigheter: pandas, matplotlib (installert via apt).
"""

import sys
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

def main():
    if len(sys.argv) < 2:
        print("Bruk: python3 plot_joint_data.py <loggfil.csv>")
        sys.exit(1)

    csv_file = sys.argv[1]
    try:
        df = pd.read_csv(csv_file)
    except FileNotFoundError:
        print(f"Fant ikke filen '{csv_file}'.")
        sys.exit(1)

    # Sjekk nødvendige kolonner
    cols_pos = ['time', 'joint_e', 'joint_d', 'joint_c', 'joint_b']
    cols_vel = ['time', 'vel_e', 'vel_d', 'vel_c', 'vel_b']
    cols_err = ['time', 'err_x_fwd', 'err_y_left', 'err_z_down', 'err_norm']

    missing = []
    for c in cols_pos + cols_vel[1:] + cols_err[1:]:
        if c not in df.columns:
            missing.append(c)
    if missing:
        print(f"Mangler kolonner: {missing}")
        sys.exit(1)

    # Relativ tid (sekunder fra første måling)
    t = df['time'].values
    t_rel = t - t[0]

    # ---------------------------
    # 1. Posisjoner
    # ---------------------------
    fig, axes = plt.subplots(3, 1, figsize=(12, 10), sharex=True)

    ax = axes[0]
    ax.plot(t_rel, df['joint_e'], label='joint_e', linewidth=1.2)
    ax.plot(t_rel, df['joint_d'], label='joint_d', linewidth=1.2)
    ax.plot(t_rel, df['joint_c'], label='joint_c', linewidth=1.2)
    ax.plot(t_rel, df['joint_b'], label='joint_b', linewidth=1.2)
    ax.set_ylabel('Leddvinkel [rad]')
    ax.set_title('Leddposisjoner')
    ax.legend(loc='best')
    ax.grid(True, alpha=0.3)

    # ---------------------------
    # 2. Hastigheter
    # ---------------------------
    ax = axes[1]
    ax.plot(t_rel, df['vel_e'], label='vel_e', linewidth=1.2)
    ax.plot(t_rel, df['vel_d'], label='vel_d', linewidth=1.2)
    ax.plot(t_rel, df['vel_c'], label='vel_c', linewidth=1.2)
    ax.plot(t_rel, df['vel_b'], label='vel_b', linewidth=1.2)
    ax.set_ylabel('Hastighet [rad/s]')
    ax.set_title('Leddhastigheter')
    ax.legend(loc='best')
    ax.grid(True, alpha=0.3)

    # ---------------------------
    # 3. Feil
    # ---------------------------
    ax = axes[2]
    ax.plot(t_rel, df['err_x_fwd'], label='err_x_fwd', linewidth=1.2)
    ax.plot(t_rel, df['err_y_left'], label='err_y_left', linewidth=1.2)
    ax.plot(t_rel, df['err_z_down'], label='err_z_down', linewidth=1.2)
    ax.plot(t_rel, df['err_norm'], label='err_norm', linewidth=1.5, linestyle='--', color='black')
    ax.set_xlabel('Relativ tid [s]')
    ax.set_ylabel('Feil [m]')
    ax.set_title('Feilkomponenter og feilnorm')
    ax.legend(loc='best')
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    # Lagre figur med samme grunnnavn som CSV-en
    out_png = csv_file.rsplit('.', 1)[0] + '_plot.png'
    plt.savefig(out_png, dpi=150)
    print(f"Plott lagret som {out_png}")
    plt.show()

if __name__ == '__main__':
    main()