#!/usr/bin/env python3
"""Logger Alpha5-testdata med metode- og punkt-tag. Skriver til log.csv i mappen du kjører fra."""

import json
import math
import numpy as np
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import String, Int32

# ---------- Alpha5 kinematikk (som i animator) ----------
def Rx3(a): c,s=np.cos(a),np.sin(a); return np.array([[1,0,0],[0,c,-s],[0,s,c]])
def Ry3(a): c,s=np.cos(a),np.sin(a); return np.array([[c,0,s],[0,1,0],[-s,0,c]])
def Rz3(a): c,s=np.cos(a),np.sin(a); return np.array([[c,-s,0],[s,c,0],[0,0,1]])
def Rx4(a): T=np.eye(4); T[:3,:3]=Rx3(a); return T
def Ry4(a): T=np.eye(4); T[:3,:3]=Ry3(a); return T
def Rz4(a): T=np.eye(4); T[:3,:3]=Rz3(a); return T

def tf(xyz, rpy):
    T=np.eye(4); T[:3,:3]=Rz3(rpy[2])@Ry3(rpy[1])@Rx3(rpy[0])
    T[:3,3]=np.array(xyz); return T

T0_1 = tf((0.124,0.0137,-0.004),(-np.pi/2,np.pi,0))
T1_2 = tf((0.0201,-0.0137,0.033),(0,np.pi/2,0))
T2_3 = tf((0.145,0,0.04),(0,0,0))
T3_4 = tf((-0.033,0.0137,0.02),(-np.pi/6,0,0))
T4_JB = tf((-0.098,0,0),(0,0,0))

def fk(q):
    q1,q2,q3,q4 = q
    T = np.eye(4)
    T = T @ T0_1 @ Rz4(q1)
    T = T @ T1_2 @ Ry4(-q2)
    T = T @ T2_3 @ Ry4(q3)
    T = T @ T3_4 @ Rx4(q4)
    return (T @ T4_JB)[:3,3].copy()

def default_ab_to_task(p_ab):
    return np.array([p_ab[0], p_ab[2], p_ab[1]])

# ---------- Logger ----------
class MethodTestLogger(Node):
    def __init__(self):
        super().__init__('method_test_logger')
        self.joint_state = None       # (time, q)
        self.target = None            # (time, target_ab)
        self.current_method = "unknown"
        self.current_point = 0        # <--- NYTT: punkt-ID
        self.last_q = None
        self.last_t = None

        # CSV-fil
        self.file = open("log.csv", "w")
        self.file.write("time,method,point_id,joint_e,joint_d,joint_c,joint_b,"
                        "vel_e,vel_d,vel_c,vel_b,"
                        "err_x_fwd,err_y_left,err_z_down,err_norm\n")

        self.js_sub = self.create_subscription(JointState, '/joint_states', self.js_cb, 10)
        self.tgt_sub = self.create_subscription(PoseStamped, '/alpha5/gui/target_in_base', self.tgt_cb, 10)
        self.status_sub = self.create_subscription(String, '/alpha5/gui/status', self.status_cb, 10)
        self.point_sub = self.create_subscription(Int32, '/current_point', self.point_cb, 10)  # <--- NYTT

    def status_cb(self, msg):
        """Les 'solver' fra status JSON for å vite aktiv metode."""
        try:
            data = json.loads(msg.data)
            if 'solver' in data:
                self.current_method = str(data['solver'])
        except Exception:
            pass

    def point_cb(self, msg):          # <--- NYTT
        self.current_point = msg.data

    def js_cb(self, msg):
        # Hent de fire hovedleddene
        names = msg.name
        pos = msg.position
        q = np.full(4, np.nan)
        for n, p in zip(names, pos):
            if n in ('joint_e','joint_d','joint_c','joint_b'):
                idx = {'joint_e':0,'joint_d':1,'joint_c':2,'joint_b':3}[n]
                q[idx] = p
        if np.any(np.isnan(q)):
            return
        q[0] = (q[0] + 2*math.pi) % (2*math.pi)
        t = self.get_clock().now().nanoseconds * 1e-9
        self.joint_state = (t, q)

    def tgt_cb(self, msg):
        t = self.get_clock().now().nanoseconds * 1e-9
        p = np.array([msg.pose.position.x, msg.pose.position.y, msg.pose.position.z])
        self.target = (t, p)

    def try_log(self):
        """Kalles av en timer for å prøve å logge hvis vi har nytt datapunkt."""
        if self.joint_state is None or self.target is None:
            return

        t_js, q = self.joint_state
        t_tgt, target_ab = self.target
        t = t_js  # Bruk joint_state-tid
        p_ee_ab = fk(q)
        p_ee_task = default_ab_to_task(p_ee_ab)
        target_task = default_ab_to_task(target_ab)
        err_task = target_task - p_ee_task
        err_norm = np.linalg.norm(err_task)

        # Hastigheter (derivert)
        if self.last_q is not None and self.last_t is not None:
            dt = t - self.last_t
            if dt > 1e-9:
                dq = (q - self.last_q) / dt
            else:
                dq = np.full(4, np.nan)
        else:
            dq = np.full(4, np.nan)

        self.last_q = q
        self.last_t = t

        # Skriv linje – nå med punkt-ID
        self.file.write(f"{t:.6f},{self.current_method},{self.current_point},"  # <--- endret
                        f"{q[0]:.6f},{q[1]:.6f},{q[2]:.6f},{q[3]:.6f},"
                        f"{dq[0]:.6f},{dq[1]:.6f},{dq[2]:.6f},{dq[3]:.6f},"
                        f"{err_task[0]:.6f},{err_task[1]:.6f},{err_task[2]:.6f},{err_norm:.6f}\n")
        # Nullstill for å unngå duplikater
        self.joint_state = None
        self.target = None

def main():
    rclpy.init()
    logger = MethodTestLogger()
    # Timer som kjører med jevne mellomrom for å logge nye data
    timer = logger.create_timer(0.02, logger.try_log)  # 50 Hz
    try:
        rclpy.spin(logger)
    except KeyboardInterrupt:
        pass
    finally:
        logger.file.close()
        logger.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()