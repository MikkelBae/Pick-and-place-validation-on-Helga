#!/usr/bin/env python3
"""
plot_velocities.py – Plott leddhastigheter mot tid fra en Alpha5-loggfil.

Bruk:
  python plot_velocities.py <loggfil.csv>

Eksempel:
  python plot_velocities.py slow_planning_log.csv

Krever: pandas, matplotlib
"""

import sys
import pandas as pd
import matplotlib.pyplot as plt

def main():
    if len(sys.argv) < 2:
        print("Bruk: python plot_velocities.py <loggfil.csv>")
        sys.exit(1)

    csv_file = sys.argv[1]

    try:
        df = pd.read_csv(csv_file)
    except FileNotFoundError:
        print(f"Fant ikke filen '{csv_file}'.")
        sys.exit(1)

    # Sjekk at vi har nødvendige kolonner
    needed = ['time', 'vel_e', 'vel_d', 'vel_c', 'vel_b']
    missing = [c for c in needed if c not in df.columns]
    if missing:
        print(f"Mangler kolonner i filen: {missing}")
        sys.exit(1)

    # Relativ tid i sekunder
    t_rel = df['time'] - df['time'].iloc[0]

    # Opprett plot
    plt.figure(figsize=(12, 6))

    plt.plot(t_rel, df['vel_e'], label='vel_e (joint 1)', linewidth=1.2)
    plt.plot(t_rel, df['vel_d'], label='vel_d (joint 2)', linewidth=1.2)
    plt.plot(t_rel, df['vel_c'], label='vel_c (joint 3)', linewidth=1.2)
    plt.plot(t_rel, df['vel_b'], label='vel_b (gripper)', linewidth=1.2, alpha=0.8)

    plt.xlabel('Relativ tid [s]')
    plt.ylabel('Hastighet [rad/s]')
    plt.title(f'Leddhastigheter – {csv_file}')
    plt.legend()
    plt.grid(True, alpha=0.3)

    # Lagre figur
    out_png = csv_file.replace('.csv', '_velocities.png')
    plt.savefig(out_png, dpi=150)
    print(f"Plott lagret som {out_png}")
    plt.show()

if __name__ == '__main__':
    main()