#!/usr/bin/env python3
"""
plot_boxplot_all.py – Lager boksplott fra flere loggfiler (P1.csv ... P8.csv).
Leser alle CSV-filer i en mappe (standard: nåværende mappe), kombinerer dem,
og viser feilkomponenter og feilnorm per metode og punkt.

Bruk:  python3 plot_boxplot_all.py [mappe_med_csv]
       Hvis mappe ikke oppgis, brukes aktuell katalog.
"""

import sys
import glob
import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def main():
    # Hent mappe fra kommandolinje, ellers '.'
    if len(sys.argv) > 1:
        folder = sys.argv[1]
    else:
        folder = "."

    # Finn alle CSV-filer i mappen (du kan justere mønsteret etter behov)
    # Anta filer som heter P1.csv, P2.csv osv.
    csv_files = sorted(glob.glob(os.path.join(folder, "P[5-8].csv")))
    if not csv_files:
        print(f"Ingen CSV-filer funnet i {folder}.")
        sys.exit(1)

    print(f"Leser {len(csv_files)} filer: {', '.join(os.path.basename(f) for f in csv_files)}")

    # Les inn alle filer og legg til 'point' kolonne basert på filnavnet (uten .csv)
    df_list = []
    for f in csv_files:
        point_name = os.path.splitext(os.path.basename(f))[0]  # f.eks. "P1"
        try:
            df = pd.read_csv(f)
            df['point'] = point_name
            df_list.append(df)
        except Exception as e:
            print(f"Advarsel: Kunne ikke lese {f}: {e}")

    if not df_list:
        print("Ingen gyldige datafiler funnet.")
        sys.exit(1)

    # Slå sammen
    df_all = pd.concat(df_list, ignore_index=True)

    # Sjekk nødvendige kolonner
    required = ["method", "err_x_fwd", "err_y_left", "err_z_down", "err_norm"]
    missing = [c for c in required if c not in df_all.columns]
    if missing:
        print(f"Mangler kolonner: {missing}")
        sys.exit(1)

    methods = df_all["method"].unique()
    points = df_all["point"].unique()
    print(f"Metoder: {', '.join(methods)}")
    print(f"Punkter: {', '.join(points)}")
    print(f"Totalt antall rader: {len(df_all)}")

    sns.set_style("whitegrid")

    # --- Plott 1: Feilnorm per metode (alle punkter samlet) ---
    plt.figure(figsize=(10, 6))
    sns.boxplot(data=df_all, x="method", y="err_norm")
    plt.title("Feilnorm per metode (alle punkter)")
    plt.xlabel("Metode")
    plt.ylabel("Feil [m]")
    plt.tight_layout()
    plt.savefig("boxplot_err_norm_all_points.png")
    plt.show()

    # --- Plott 2: Feilnorm per punkt, splittet på metode ---
    plt.figure(figsize=(12, 6))
    sns.boxplot(data=df_all, x="point", y="err_norm", hue="method")
    plt.title("Feilnorm per punkt og metode")
    plt.xlabel("Punkt")
    plt.ylabel("Feil [m]")
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.tight_layout()
    plt.savefig("boxplot_err_norm_by_point.png")
    plt.show()

    # --- Plott 3: Komponentvise feil per metode (ett panel per komponent) ---
    comps = ["err_x_fwd", "err_y_left", "err_z_down"]
    titles = ["Feil X (fremover)", "Feil Y (venstre)", "Feil Z (nedover)"]
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    for ax, comp, title in zip(axes, comps, titles):
        sns.boxplot(data=df_all, x="method", y=comp, ax=ax)
        ax.set_title(title)
        ax.set_xlabel("Metode")
        ax.set_ylabel("Feil [m]")
    plt.tight_layout()
    plt.savefig("boxplot_components_per_method.png")
    plt.show()

    # --- Plott 4: Komponentfeil per punkt og metode (feilnorm kunne også vært med) ---
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    for ax, comp, title in zip(axes, comps, titles):
        sns.boxplot(data=df_all, x="point", y=comp, hue="method", ax=ax)
        ax.set_title(title)
        ax.set_xlabel("Punkt")
        ax.set_ylabel("Feil [m]")
        # Legg legend utenfor om ønskelig, eller behold for hvert subplot (kan bli rotete)
        # Vi flytter legend til høyre for siste subplot
    # Fjern duplikate legends i loop – behold bare én felles legend
    # Vi kan lage en felles legend manuelt, men for enkelhet beholder vi individuelle
    plt.tight_layout()
    plt.savefig("boxplot_components_by_point.png")
    plt.show()

if __name__ == "__main__":
    main()