#!/usr/bin/env python3
"""
plot_min_error_raw.py – Finn minste err_norm per punkt og metode fra rådata.

Leser alle P*.csv i en mappe, bestemmer punkt-ID fra filnavnet (P1.csv -> P1),
og finner for hver metode den minste feilnormen i det punktet.
Deretter lages et boksplott av disse minimumsverdiene per metode.

Bruk:  python plot_min_error_raw.py [mappe_med_csv]
       Standard er nåværende katalog.
"""

import sys
import os
import glob
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def main():
    folder = sys.argv[1] if len(sys.argv) > 1 else "."

    # Hent alle P*.csv – unngå _dwell, _clean o.l.
    raw_files = sorted(glob.glob(os.path.join(folder, "P?.csv")))
    if not raw_files:
        # Prøv også P??.csv dersom du har P10, P11 osv.
        raw_files = sorted(glob.glob(os.path.join(folder, "P*.csv")))
        # Filtrer bort kjente suffikser
        raw_files = [f for f in raw_files if "_dwell" not in f and "_clean" not in f]

    if not raw_files:
        print("Ingen rådatafiler (f.eks. P1.csv) funnet.")
        sys.exit(1)

    print(f"Leser {len(raw_files)} filer: {', '.join(os.path.basename(f) for f in raw_files)}")

    records = []

    for f in raw_files:
        # Punktnavn fra filnavn: P1.csv -> P1
        point = os.path.splitext(os.path.basename(f))[0]

        try:
            df = pd.read_csv(f)
        except Exception as e:
            print(f"FEIL: {f} kunne ikke leses ({e})")
            continue

        if not {"method", "err_norm"}.issubset(df.columns):
            print(f"Mangler kolonner i {f}, hopper over.")
            continue

        # For hver metode i filen, finn minste err_norm
        for method, group in df.groupby("method"):
            min_err = group["err_norm"].min()
            records.append({"point": point, "method": method, "min_err_norm": min_err})

    if not records:
        print("Ingen gyldige data funnet.")
        sys.exit(1)

    summary = pd.DataFrame(records)

    # Tabell i terminalen
    print("\n=== Minimum error norm per point and method (from raw data) ===")
    piv = summary.pivot_table(values="min_err_norm", index="point", columns="method")
    print(piv.to_string(float_format="%.6f"))

    # Boksplott: min_err_norm per metode
    plt.figure(figsize=(10, 6))
    sns.boxplot(data=summary, x="method", y="min_err_norm")
    sns.stripplot(data=summary, x="method", y="min_err_norm", color="black", alpha=0.6, jitter=True)
    sns.boxplot(data=summary, x="method", y="min_err_norm", palette="Set2")
    plt.title("Minimum error norm per method (over all points)")
    plt.xlabel("Method")
    plt.ylabel("Min. error norm [m]")
    plt.ylim(-0.01, 0.08)
    plt.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    plt.savefig("boxplot_min_err_raw.png")
    plt.show()

    # Punktplot for å se variasjon mellom punkter
    plt.figure(figsize=(12, 6))
    sns.pointplot(data=summary, x="point", y="min_err_norm", hue="method",
                  markers="o", linestyles="--")
    plt.title("Minimum error norm per point and method")
    plt.xlabel("Point")
    plt.ylabel("Min. error norm [m]")
    #plt.grid(axis="y", alpha=0.3)
    plt.grid(True)
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.tight_layout()
    plt.savefig("pointplot_min_err_raw.png")
    plt.show()

if __name__ == "__main__":
    main()