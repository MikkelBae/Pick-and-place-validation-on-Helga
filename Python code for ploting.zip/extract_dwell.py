#!/usr/bin/env python3
"""
extract_dwell.py – Trekk ut kun «dwell»-fasen fra en Alpha5-loggfil.

Dwell = perioden der armen har nådd målet og står stille (lave hastigheter),
        men FØR den returnerer til home (feilen faller drastisk).

Bruk:
  python3 extract_dwell.py <loggfil.csv>

Resultatet lagres som <loggfil>_dwell.csv i samme mappe.
"""

import sys
import pandas as pd
import numpy as np

# ---- Parametre du kan justere ----
VEL_THRESH = 0.015          # rad/s – under dette regnes leddet som stillestående
DWELL_MIN_SAMPLES = 15      # antall påfølgende målinger som må ha lav hastighet
ERR_DROP_FACTOR = 0.5       # hvis err_norm faller under (faktor * max i nærheten) → retur til home
# ---------------------------------

def find_dwell_indices(df):
    """
    Returner start- og sluttindeks for dwell-fasen.
    Bruker hastighetskolonnene til å finne når armen først stopper,
    og feilnormen til å oppdage når den forlater dwell.
    """
    vel_cols = ['vel_e', 'vel_d', 'vel_c', 'vel_b']
    if not all(c in df.columns for c in vel_cols + ['err_norm']):
        raise ValueError("Mangler nødvendige kolonner (vel_e..vel_b, err_norm).")

    # 1. Finn maks absoluttverdi av hastighetene per rad
    max_vel = df[vel_cols].abs().max(axis=1)

    # 2. Finn perioder med lav hastighet
    low_vel = max_vel < VEL_THRESH

    # 3. Finn den første gangen vi har en serie med DWELL_MIN_SAMPLES lave målinger
    #    – dette er kandidat for start på dwell.
    in_dwell = False
    dwell_start = None
    dwell_end = None

    # Vi går gjennom tidsserien
    for i in range(len(df)):
        if not in_dwell:
            # Sjekk om vi har nok lave målinger på rad
            if i + DWELL_MIN_SAMPLES <= len(df) and all(low_vel.iloc[i:i+DWELL_MIN_SAMPLES]):
                dwell_start = i
                in_dwell = True
        else:
            # Så snart vi er i dwell, se etter slutten:
            # Bruk err_norm – hvis den har falt mye i forhold til et glidende maksimum
            # i dwell-fasen, antar vi at armen har begynt å gå tilbake.
            if i >= dwell_start + 5:   # vent litt så vi får et stabilt max
                dwell_so_far = df['err_norm'].iloc[dwell_start:i+1]
                max_err = dwell_so_far.max()
                current_err = df['err_norm'].iloc[i]
                if current_err < ERR_DROP_FACTOR * max_err and max_err > 1e-4:
                    dwell_end = i - 1   # dwell slutt før fallet
                    break

    if dwell_start is not None:
        if dwell_end is None:
            dwell_end = len(df) - 1
        return dwell_start, dwell_end
    else:
        return None, None

def main():
    if len(sys.argv) < 2:
        print("Bruk: python3 extract_dwell.py <loggfil.csv>")
        sys.exit(1)

    input_file = sys.argv[1]
    df = pd.read_csv(input_file)

    # Sorter etter tid (sikkerhet)
    if 'time' in df.columns:
        df = df.sort_values('time').reset_index(drop=True)

    start, end = find_dwell_indices(df)
    if start is None:
        print("Fant ingen dwell-periode (ingen lang nok pause med lav hastighet).")
        sys.exit(0)

    dwell_df = df.iloc[start:end+1].copy()
    output_file = input_file.replace('.csv', '_dwell.csv')
    dwell_df.to_csv(output_file, index=False)
    print(f"Dwell-periode funnet fra rad {start} til {end} ({len(dwell_df)} punkter).")
    print(f"Lagdret som {output_file}")

if __name__ == '__main__':
    main()